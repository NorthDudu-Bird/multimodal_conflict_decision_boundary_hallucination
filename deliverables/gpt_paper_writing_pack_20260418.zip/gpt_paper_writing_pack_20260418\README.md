﻿# GPT Paper Writing Pack

This package contains the final paper-facing materials after the last cleanup, full rerun, and reproducibility verification pass.

Highlights:
- final balanced evaluation manifest
- paper workflow docs
- main/auxiliary/robustness/parser/appendix result files
- reproducibility audit showing the rerun matched the locked canonical outputs

Suggested reading order:
1. results/final_result_summary.md
2. results/reproducibility_audit.md
3. results/main/table1_main_metrics.md
4. results/main/main_stats_summary.md
5. results/robustness/prompt_variant_summary.md
6. results/results_discussion_summary.md
