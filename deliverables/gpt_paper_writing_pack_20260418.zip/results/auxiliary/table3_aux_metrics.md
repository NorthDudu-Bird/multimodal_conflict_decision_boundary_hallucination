# Table 3. Auxiliary A1/A2 metrics

| model | condition | n | compliance | conflict_aligned | faithful |
| --- | --- | --- | --- | --- | --- |
| qwen2vl7b | A1_forced_choice_red_family | 300 | 55.67% [50.01%, 61.18%] | 55.67% [50.01%, 61.18%] | 44.33% [38.82%, 49.99%] |
| qwen2vl7b | A2_counterfactual_assumption | 300 | 90.67% [86.84%, 93.46%] | 90.67% [86.84%, 93.46%] | 9.33% [6.54%, 13.16%] |
| llava15_7b | A1_forced_choice_red_family | 300 | 85.33% [80.88%, 88.89%] | 85.33% [80.88%, 88.89%] | 14.67% [11.11%, 19.12%] |
| llava15_7b | A2_counterfactual_assumption | 300 | 100.00% [98.74%, 100.00%] | 100.00% [98.74%, 100.00%] | 0.00% [0.00%, 1.26%] |
| internvl2_8b | A1_forced_choice_red_family | 300 | 73.67% [68.41%, 78.33%] | 73.67% [68.41%, 78.33%] | 26.33% [21.67%, 31.59%] |
| internvl2_8b | A2_counterfactual_assumption | 300 | 100.00% [98.74%, 100.00%] | 100.00% [98.74%, 100.00%] | 0.00% [0.00%, 1.26%] |
