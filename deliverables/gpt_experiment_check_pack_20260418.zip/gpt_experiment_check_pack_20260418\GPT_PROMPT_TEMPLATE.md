﻿# GPT Review Prompt Template

Please review this experiment check pack as a strict but fair empirical-paper reviewer.

Constraints:
- Do not rewrite the research direction.
- Do not ask for broad project expansion.
- Treat this as a narrow empirical paper about whether VLM outputs on a car-body primary-color task are driven more by visual evidence or by misleading color text prompts.
- Judge the current strengthened evidence package within its final claim boundary.

Please read at least:
- results/final_result_summary.md
- results/reproducibility_audit.md
- results/strengthening_audit_summary.md
- results/main/table1_main_metrics.md
- results/main/main_stats_summary.md
- results/robustness/prompt_variant_summary.md
- results/parser/label_mapping_audit.md
- results/appendix/stanford_core_sanity_check.md
- results/results_discussion_summary.md

Then answer in this structure:
1. Overall verdict: pass with current claim boundary / pass after small wording fixes / not yet pass.
2. Coverage check: C0-C4 and A1/A2.
3. Statistics check: CI, exact tests, and whether anything important is missing.
4. Robustness and reliability check: prompt variants, parser audit, source sanity, reproducibility rerun.
5. Claim boundary: which conclusions can stay and which must stay downgraded.
6. Must-fix list: at most 5 concrete items.

Important:
- Prefer identifying real evidence gaps over broad stylistic advice.
- Be explicit about whether the observed LLaVA-1.5-7B effect is robust, partially robust, or template-sensitive.
