﻿# GPT Experiment Check Pack

This pack is a high-signal review bundle for checking whether the final experiment package is submission-ready enough.

Use it to verify:
- coverage of C0-C4 and A1/A2
- quality of confidence intervals and exact tests
- prompt wording robustness
- parser reliability
- appendix source sanity check
- reproducibility after full rerun

Suggested reading order:
1. results/final_result_summary.md
2. results/reproducibility_audit.md
3. results/strengthening_audit_summary.md
4. results/main/table1_main_metrics.md
5. results/main/main_stats_summary.md
6. results/robustness/prompt_variant_summary.md
7. results/parser/label_mapping_audit.md
8. results/appendix/stanford_core_sanity_check.md
9. results/results_discussion_summary.md
